import thermiteImg from "./thermite.png";

export {thermiteImg};