export type Letter = 'Q' | 'W' | 'E' | 'R' | 'A' | 'S' | 'D';
export type LetterState = 'done' | 'fail' | '';

export const Letters: Letter[] = ['Q', 'W', 'E', 'R', 'A', 'S', 'D'];
