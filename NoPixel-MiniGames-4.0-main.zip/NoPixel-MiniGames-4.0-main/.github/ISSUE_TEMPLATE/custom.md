---
name: Custom issue template
about: In the case that no other template describes your issue
title: "[CUSTOM]"
labels: ''
assignees: MaximilianAdF

---


